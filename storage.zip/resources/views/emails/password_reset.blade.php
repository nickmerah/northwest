<!DOCTYPE html>
<html>

<head>
    <title>Password Reset</title>
</head>

<body>
    <h1>Password Reset Request</h1>
    <p>You requested to reset your password. Your number Password is</p>
    <b>{{ $resetLink }}</b>
    <p>Additionally, your surname in small letters is still your password.</p>
    <p>Admin, nwcn</p>
</body>

</html>