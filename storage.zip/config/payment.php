<?php

return [
    'gateways' => ['PayStack'],
    'fee_types' => ['1', '2', '3', '4', '5', '6'],
];
