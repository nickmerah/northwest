<?php
return [
    'name' => env('SCHOOL_NAME', 'College Portal'),
];
