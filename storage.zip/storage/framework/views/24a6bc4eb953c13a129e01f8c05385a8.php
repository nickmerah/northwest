  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">
          <ul class="breadcrumb breadcrumb-style ">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">My Olevel Results</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i></a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>
          <div class="container-fluid p-0">
              <div class="row">
                  <div class="col-md-9 col-xl-12">
                      <div class="tab-content">
                          <div class="tab-pane fade show active" id="application" role="tabpanel">
                              <div class="card">
                                  <div class="card-body">
                                      <h5 class="card-title mb-0"><strong>O'LEVEL RESULTS</strong></h5>
                                      <hr>
                                      <form id="update_profile" name="update_profile" action="<?php echo e(route('admissions.olevel')); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php if(empty($olevelResults->data)): ?>
                                          <div class="row">
                                              <div class="col-12 col-md-6 col-lg-6">
                                                  <div class="card">
                                                      <div class="card-header">
                                                          <h4>First Sitting</h4>
                                                      </div>
                                                      <div class="card-body">
                                                          <div class="table-responsive">
                                                              <table class="table">
                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <label class="form-label"><strong>Examination Type</strong></label>
                                                                          <select name="first[examName]" class="form-control" required>
                                                                              <option value="">Select Exam Type</option>
                                                                              <?php $__currentLoopData = ['NECO', 'WAEC/WASCE', 'NABTEB']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etypes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                              <option><?php echo e($etypes); ?></option>
                                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          </select>
                                                                      </td>
                                                                  </tr>
                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <label class="form-label"><strong>Center No</strong></label>
                                                                          <input name="first[centerNo]" type="text" class="form-control" required>
                                                                      </td>
                                                                  </tr>
                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <label class="form-label"><strong>Examination No</strong></label>
                                                                          <input name="first[examNo]" type="text" class="form-control" required>
                                                                      </td>
                                                                  </tr>
                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <label class="form-label"><strong>Month</strong></label>
                                                                          <select name="first[examMonth]" class="form-control" required>
                                                                              <option value="">Select Month</option>
                                                                              <?php $__currentLoopData = ['Jan','Feb','March','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                              <option value='<?php echo e($month); ?>'><?php echo e($month); ?></option>
                                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          </select>
                                                                      </td>
                                                                  </tr>
                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <label class="form-label"><strong>Year</strong></label>
                                                                          <select name="first[examYear]" class="form-control" required>
                                                                              <option value="">Select Year</option>
                                                                              <?php for($syear = now()->year; $syear >= 1980; $syear--): ?>
                                                                              <option value="<?php echo e($syear); ?>"><?php echo e($syear); ?></option>
                                                                              <?php endfor; ?>
                                                                          </select>
                                                                      </td>
                                                                  </tr>

                                                                  <tr>
                                                                      <td colspan="3">
                                                                          <br>
                                                                          <h6>Subject & Grades</h6>
                                                                          <div class="row">
                                                                              <?php for($i = 1; $i <= 8; $i++): ?>
                                                                                  <div class="mb-1 col-md-8">
                                                                                  <select name="first[subjectName][]" class="form-control">
                                                                                      <option value="">Select Subject</option>
                                                                                      <?php $__currentLoopData = $olevelSubjects['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                      <option><?php echo e($subject['subjectname']); ?></option>
                                                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                  </select>
                                                                          </div>
                                                                          <div class="mb-1 col-md-4">
                                                                              <select name="first[grade][]" class="form-control">
                                                                                  <option value="">Grade</option>
                                                                                  <?php $__currentLoopData = $olevelGrades['data']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                  <option><?php echo e($grade); ?></option>
                                                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                              </select>
                                                                          </div>
                                                                          <?php endfor; ?>
                                                          </div>
                                                          </td>
                                                          </tr>
                                                          </table>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>

                                          <div class="col-12 col-md-6 col-lg-6">
                                              <div class="card">
                                                  <div class="card-header">
                                                      <h4>Second Sitting</h4>
                                                  </div>
                                                  <div class="card-body">
                                                      <div class="table-responsive">
                                                          <table class="table">
                                                              <tr>
                                                                  <td colspan="3">
                                                                      <label class="form-label"><strong>Examination Type</strong></label>
                                                                      <select name="second[examName]" class="form-control">
                                                                          <option value="">Select Exam Type</option>
                                                                          <?php $__currentLoopData = ['NECO', 'WAEC/WASCE', 'NABTEB']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etypes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                          <option><?php echo e($etypes); ?></option>
                                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                      </select>
                                                                  </td>
                                                              </tr>
                                                              <tr>
                                                                  <td colspan="3">
                                                                      <label class="form-label"><strong>Center No</strong></label>
                                                                      <input name="second[centerNo]" type="text" class="form-control">
                                                                  </td>
                                                              </tr>
                                                              <tr>
                                                                  <td colspan="3">
                                                                      <label class="form-label"><strong>Examination No</strong></label>
                                                                      <input name="second[examNo]" type="text" class="form-control">
                                                                  </td>
                                                              </tr>
                                                              <tr>
                                                                  <td colspan="3">
                                                                      <label class="form-label"><strong>Month</strong></label>
                                                                      <select name="second[examMonth]" class="form-control">
                                                                          <option value="">Select Month</option>
                                                                          <?php $__currentLoopData = ['Jan','Feb','March','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                          <option value='<?php echo e($month); ?>'><?php echo e($month); ?></option>
                                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                      </select>
                                                                  </td>
                                                              </tr>
                                                              <tr>
                                                                  <td colspan="3">
                                                                      <label class="form-label"><strong>Year</strong></label>
                                                                      <select name="second[examYear]" class="form-control">
                                                                          <option value="">Select Year</option>
                                                                          <?php for($syear = now()->year; $syear >= 1980; $syear--): ?>
                                                                          <option value="<?php echo e($syear); ?>"><?php echo e($syear); ?></option>
                                                                          <?php endfor; ?>
                                                                      </select>
                                                                  </td>
                                                              </tr>
                                                              <tr>
                                                                  <td colspan="3"><br>
                                                                      <h6>Subject & Grades</h6>
                                                                      <div class="row">
                                                                          <?php for($i = 1; $i <= 8; $i++): ?>
                                                                              <div class="mb-1 col-md-8">
                                                                              <select name="second[subjectName][]" class="form-control">
                                                                                  <option value="">Select Subject</option>
                                                                                  <?php $__currentLoopData = $olevelSubjects['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                  <option><?php echo e($subject['subjectname']); ?></option>
                                                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                              </select>
                                                                      </div>
                                                                      <div class="mb-1 col-md-4">
                                                                          <select name="second[grade][]" class="form-control">
                                                                              <option value="">Grade</option>
                                                                              <?php $__currentLoopData = $olevelGrades['data']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                              <option><?php echo e($grade); ?></option>
                                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          </select>
                                                                      </div>
                                                                      <?php endfor; ?>
                                                      </div>
                                                      </td>
                                                      </tr>
                                                      </table>
                                                  </div>
                                              </div>
                                          </div>
                                  </div>
                                  <?php if($applicantStatus['biodata'] == 1 ): ?>
                                  <button class="btn btn-success"><i class="fas fa-check"></i> Save O'Level Results</button>
                                  <?php else: ?>
                                  <div class="alert alert-danger alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>BIODATA </strong> NOT YET SAVED.
                                      </div>
                                  </div>
                                  <?php endif; ?>
                              </div>
                              <?php else: ?>
                              <table class="table table-hover my-0" style="font-size:12px">
                                  <thead>
                                      <tr>
                                          <th>Exam Type</th>
                                          <th>Subject Name</th>
                                          <th>Grade</th>
                                          <th>Date Obtained</th>
                                          <th>CenterNo</th>
                                          <th>ExamNo</th>
                                          <th>Sitting</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__currentLoopData = $olevelResults->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $olevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($olevel['examName']); ?></td>
                                          <td><?php echo e($olevel['subjectName']); ?></td>
                                          <td><?php echo e($olevel['grade']); ?></td>
                                          <td><?php echo e($olevel['examMonth']); ?>, <?php echo e($olevel['examYear']); ?></td>
                                          <td><?php echo e($olevel['centerNo']); ?></td>
                                          <td><?php echo e($olevel['examNo']); ?></td>
                                          <td><?php echo e($olevel['sitting']); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                              </table>
                              <br />

                              <?php if($applicantStatus['olevels'] == 1 ): ?>
                              <a href="<?php echo e(route('admissions.jamb')); ?>" class="btn btn-info">
                                  <i class="fas fa-info"></i> Click here to Continue
                              </a>
                              <?php endif; ?>
                              <?php endif; ?>
                              <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/olevel.blade.php ENDPATH**/ ?>