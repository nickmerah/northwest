<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Delta State Polytechnic, Ogwashi-Uku - Application Portal</title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="https://portal.mydspg.edu.ng/admissions/assets/css/app.min.css">
    <!-- Template CSS -->
    <link rel="stylesheet" href="https://portal.mydspg.edu.ng/admissions/assets/css/style.css">
    <link rel="stylesheet" href="https://portal.mydspg.edu.ng/admissions/assets/css/components.css">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="https://portal.mydspg.edu.ng/admissions/assets/css/custom.css">
    <style>
        .marquee-container {
            background-color: darkgreen;
            color: white;
            padding: 10px;
            font-size: 18px;
            overflow: hidden;
            white-space: nowrap;
            position: relative;
        }

        .marquee {
            display: inline-block;
            animation: marquee 20s linear infinite;
        }

        @keyframes marquee {
            from {
                transform: translateX(100%);
            }

            to {
                transform: translateX(-100%);
            }
        }
    </style>
</head>

<body style="background-color: white">

    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar sticky">
                <div class="form-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
                        <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                                <i data-feather="maximize"></i>
                            </a></li>

                        <h3> Delta State Polytechnic, Ogwashi-Uku</h3>

                    </ul>
                </div>
                <ul class="navbar-nav navbar-right">


                    <li class="dropdown"> <strong> HNDFT2025000732</strong> </li>
                </ul>
            </nav>
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="https://portal.mydspg.edu.ng/admissions/applicant"> <img alt="image" src="https://portal.mydspg.edu.ng/admissions/assets/img/logo.png" class="header-logo" /> <span class="logo-name">DSPG </span>
                        </a>
                    </div>
                    <div class="sidebar-user">

                        <div class="sidebar-user-details">
                            <div class="user-name">ADMISSION PORTAL </div>

                        </div>
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">MENU</li>
                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/"><i data-feather="monitor"></i><span>Home</span></a></li>
                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/my_application"><i data-feather="monitor"></i><span>My Application</span></a></li>
                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/application_forms"><i data-feather="download"></i><span>Application Forms</span></a></li>







                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/checkpayment"><i data-feather="check"></i><span>Check Payment</span></a></li>
                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/phistory"><i data-feather="dollar-sign"></i><span>Payment History</span></a></li>
                        <li><a class="nav-link" href="https://portal.mydspg.edu.ng/admissions/applicant/logout"><i data-feather="log-out"></i><span>Logout</span></a></li>


                    </ul>
                </aside>
            </div>
            <script>
                function openAndPrintAdmissionLetter() {
                    const url = "https://portal.mydspg.edu.ng/admissions/applicant/admletter";
                    const printWindow = window.open(url, "_blank");

                    printWindow.onload = function() {
                        printWindow.focus();
                        printWindow.print();
                    };

                    setTimeout(() => {
                        printWindow.close();
                    }, 500);
                }
            </script>
            <!-- Main Content --> <!-- Main Content -->
            <div class="main-content">
                <section class="section">

                    <ul class="breadcrumb breadcrumb-style ">
                        <li class="breadcrumb-item">
                            <h4 class="page-title m-b-0">Dashboard</h4>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="https://portal.mydspg.edu.ng/admissions/applicant">
                                <i class="fas fa-home"></i></a>
                        </li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ul>


                    <div class="alert alert-light alert-has-icon">
                        <div class="alert-icon"><i class="far fa-user"></i></div>
                        <div class="alert-body">
                            <div class="alert-title"> <small>
                                    HNDFT2025000732 | <strong> NWASAH</strong>, KOSISOCHUKWU MIRACLE |
                                    <strong> HND NETWORKING AND CLOUD COMPUTING </strong>|
                                    2025 / 2026</small>

                            </div>

                        </div>
                    </div>

                    <div class="marquee-container">
                        <div class="marquee">
                            If you have successfully made payment and its not reflecting, click on 'Check Payment' to reprocess.
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-lg-4 col-sm-4">
                            <div class="card">
                                <div class="card-statistic-4">
                                    <div class="info-box7-block">
                                        <h6 class="m-b-20 text-right">Application Fee</h6>
                                        <h4 class="text-right"><i class="fas fa-dollar-sign pull-left bg-green c-icon"></i><span>&#8358; 16,000</span>
                                        </h4>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-4 col-sm-6">
                            <div class="card">
                                <div class="card-statistic-4">
                                    <div class="info-box7-block">
                                        <h6 class="m-b-20 text-right">Application Status</h6>
                                        <h4 class="text-right"><i class="fas fa-users pull-left bg-cyan c-icon"></i><span>
                                                <b style='color:green'>SUBMITTED</b>

                                            </span>
                                        </h4>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-sm-6">
                            <div class="card">
                                <div class="card-statistic-4">
                                    <div class="info-box7-block">
                                        <h6 class="m-b-20 text-right">Admission Status</h6>
                                        <h4 class="text-right"><i class="fas fa-user-tag pull-left bg-red c-icon"></i><span>
                                                <b style='color:red'>NOT ADMITTED</b>

                                            </span>
                                        </h4>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-12 col-sm-12 col-lg-12">
                            <div class="activities">

                                <div class="activity">
                                    <div class="activity-icon bg-success text-white">
                                        <i class="fas fa-money-bill"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Application Fee </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:green'>PAID</b> </span></p>
                                    </div>
                                </div>


                                <div class="activity">
                                    <div class="activity-icon bg-info text-white">
                                        <i class="fas fa-user-alt"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Biodata </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:green'>COMPLETED</b> </span></p>
                                    </div>
                                </div>

                                <div class="activity">
                                    <div class="activity-icon bg-warning text-white">
                                        <i class="fab fa-wpforms"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Application Forms </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:green'>SUBMITTED</b> </span></p>
                                    </div>
                                </div>

                                <div class="activity">
                                    <div class="activity-icon bg-danger text-white">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Admission Status </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:red'>NOT ADMITTED</b> </span></p>

                                    </div>
                                </div>

                                <div class="activity">
                                    <div class="activity-icon bg-secondary text-white">
                                        <i class="fas fa-money-bill-alt"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Acceptance Fee </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:red'>NOT PAID</b> </span></p>
                                    </div>
                                </div>

                                <div class="activity">
                                    <div class="activity-icon bg-primary text-white">
                                        <i class="fas fa-money-bill-alt"></i>
                                    </div>
                                    <div class="activity-detail">
                                        <div class="mb-2">
                                            <span class="text-job">
                                                <h6>Result Verification Fee </h6>
                                            </span>

                                        </div>
                                        <p><span class="font-13"> <b style='color:red'>NOT PAID</b> </span></p>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>


            </div>

            </section>

        </div>
        <footer class="main-footer">
            <div class="footer-left">
                Copyright &copy; 2023 <div class="bullet"></div> DPSG</a>
            </div>
            <div class="footer-right">
            </div>
        </footer>
    </div>
    </div>
    <!-- General JS Scripts -->
    <script src="https://portal.mydspg.edu.ng/admissions/assets/js/app.min.js"></script>
    <!-- JS Libraies -->
    <script src="https://portal.mydspg.edu.ng/admissions/assets/bundles/apexcharts/apexcharts.min.js"></script>
    <script src="https://portal.mydspg.edu.ng/admissions/assets/bundles/amcharts4/core.js"></script>
    <script src="https://portal.mydspg.edu.ng/admissions/assets/bundles/amcharts4/charts.js"></script>
    <script src="https://portal.mydspg.edu.ng/admissions/assets/bundles/amcharts4/animated.js"></script>
    <script src="https://portal.mydspg.edu.ng/admissions/assets/bundles/jquery.sparkline.min.js"></script>
    <!-- Page Specific JS File -->
    <script src="https://portal.mydspg.edu.ng/admissions/assets/js/page/index.js"></script>
    <!-- Template JS File -->
    <script src="https://portal.mydspg.edu.ng/admissions/assets/js/scripts.js"></script>
    <!-- Custom JS File -->
    <script src="https://portal.mydspg.edu.ng/admissions/assets/js/custom.js"></script>
</body>


</html><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/dashboard.blade.php ENDPATH**/ ?>