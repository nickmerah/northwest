  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">
          <ul class="breadcrumb breadcrumb-style">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">APPLICATION FORM</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i>
                  </a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>

          <?php
          use Illuminate\Support\Str;
          ?>

          <div class="col-md-9 col-xl-12">
              <div class="tab-content">
                  <div class="tab-pane fade show active" id="payslip" role="tabpanel">
                      <div id="printableArea">
                          <?php if(isset($biodetail)): ?>

                          <div class="card">
                              <br />
                              <div align="center">
                                  <img src="<?php echo e(asset('public/assets/img/logo.png')); ?>" alt="nw" width="120" height="131">
                                  <br><br>
                                  <h3><?php echo e(strtoupper($SCHOOLNAME)); ?></h3>
                                  <strong style="font-size:20px; color:#900">
                                      <u><?php echo e($applicantStatus['appyear']); ?> / <?php echo e($applicantStatus['appyear'] + 1); ?> ADMISSION ACKNOWLEDGEMENT CARD</u>
                                  </strong>
                              </div>

                              <div class="card-body">
                                  <h5 class="card-title mb-0"><strong>CANDIDATE'S INFORMATION</strong></h5>
                                  <div class="row">
                                      <table class="table table-bordered table-sm" width="100%" style="font-size:13px">
                                          <tbody>
                                              <tr>
                                                  <td width="170"><strong>Application No</strong></td>
                                                  <td colspan="2"><?php echo e($biodetail->applicationNumber); ?></td>
                                                  <td rowspan="4">
                                                      <img alt="Photo" src="<?php echo e($passportUrl); ?>"
                                                          class="rounded-circle img-responsive mt-3" width="135" height="131" />
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Surname</strong></td>
                                                  <td colspan="2"><?php echo e($biodetail->surname); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Firstname</strong></td>
                                                  <td colspan="2"><?php echo e($biodetail->firstname); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Othernames</strong></td>
                                                  <td colspan="2"><?php echo e($biodetail->othernames); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Email</strong></td>
                                                  <td><?php echo e($biodetail->studentEmail); ?></td>
                                                  <td><strong>HomeTown/Village</strong></td>
                                                  <td><?php echo e($biodetail->homeTown); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Phone Number</strong></td>
                                                  <td><?php echo e($biodetail->studentPhoneNo); ?></td>
                                                  <td><strong>Gender</strong></td>
                                                  <td><?php echo e($biodetail->gender); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Date of Birth</strong></td>
                                                  <td><?php echo e(\Carbon\Carbon::parse($biodetail->birthDate)->format('F d, Y')); ?></td>
                                                  <td><strong>Marital Status</strong></td>
                                                  <td><?php echo e($biodetail->maritalStatus); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Permanent Home Address</strong></td>
                                                  <td colspan="3"><?php echo e($biodetail->studentHomeAddress); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Contact Address</strong></td>
                                                  <td colspan="3"><?php echo e($biodetail->contactAddress); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>State</strong></td>
                                                  <td><?php echo e($biodetail->stateofOrigin['state_name']); ?></td>
                                                  <td><strong>LGA</strong></td>
                                                  <td><?php echo e($biodetail->lga['lga_name']); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>First Course</strong></td>
                                                  <td><?php echo e($biodetail->firstChoiceCourse['programme_option']); ?></td>
                                                  <td><strong>Second Course</strong></td>
                                                  <td><?php echo e($biodetail->secondChoiceCourse['programme_option']); ?></td>
                                              </tr>
                                              <tr>
                                                  <td><strong>Programme</strong></td>
                                                  <td><?php echo e($biodetail->programme['programme_name']); ?></td>
                                                  <td><strong>Programme Type</strong></td>
                                                  <td><?php echo e($biodetail->programmeType['programmet_name']); ?></td>
                                              </tr>
                                          </tbody>
                                      </table>


                                      <br />
                                      <h5 class="card-title mb-0"><strong>NOTICES</strong></h5>
                                      <hr>
                                      <table class="table table-hover my-0" width="100%" style="font-size:12px">

                                          <tbody>


                                              <tr style="font-size: 14px;">
                                                  <td>
                                                      <ul>
                                                          <li>Applicants are not allowed to enter the examination hall with any paper or mobile devices of any kind</li>
                                                          <li>Applicants must come along with their acknowledgement card to the examination and interview venue</li>
                                                      </ul>
                                                  </td>
                                              </tr>


                                          </tbody>
                                      </table>

                                  </div>
                              </div>
                          </div>

                          <?php endif; ?>
                      </div>
                  </div>
              </div>
              <input type="button" onClick="printDiv('printableArea')" value="Print Acknowledgement Card" class='btn btn-primary'>
          </div>

      </section>
  </div>

  <script type="application/javascript">
      function printDiv(divName) {
          var printContents = document.getElementById(divName).innerHTML;
          var originalContents = document.body.innerHTML;

          document.body.innerHTML = printContents;

          window.print();

          document.body.innerHTML = originalContents;
      }
  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/applicationcard.blade.php ENDPATH**/ ?>