  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">
          <ul class="breadcrumb breadcrumb-style">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">Declaration</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i>
                  </a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>

          <div class="col-md-9 col-xl-12">
              <div class="tab-content">
                  <div class="tab-pane fade show active" id="application" role="tabpanel">
                      <div class="card">
                          <div class="card-body">

                              <?php if(isset($biodetail)): ?>
                              <h5 class="card-title mb-0"><strong>BIODATA</strong></h5>
                              <hr>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Application Number:</strong><br> <?php echo e($biodetail->applicationNumber); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Surname:</strong><br> <?php echo e($biodetail->surname); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Firstname:</strong><br> <?php echo e($biodetail->firstname); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Othername:</strong><br> <?php echo e($biodetail->othernames); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Email:</strong><br> <?php echo e($biodetail->studentEmail); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Phone Number:</strong><br> <?php echo e($biodetail->studentPhoneNo); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Gender:</strong><br> <?php echo e($biodetail->gender); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Marital Status:</strong><br> <?php echo e($biodetail->maritalStatus); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Date of Birth:</strong><br> <?php echo e(\Carbon\Carbon::parse($biodetail->birthDate)->format('F d, Y')); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>HomeTown:</strong><br> <?php echo e($biodetail->homeTown); ?>

                                  </div>
                              </div>
                              <div class="mb-3">
                                  <strong>Permanent Home Address:</strong><br> <?php echo e($biodetail->studentHomeAddress); ?>

                              </div>
                              <div class="mb-3">
                                  <strong>Contact Address:</strong><br> <?php echo e($biodetail->contactAddress); ?>

                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>State:</strong><br> <?php echo e($biodetail->stateofOrigin['state_name']); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>LGA:</strong><br> <?php echo e($biodetail->lga['lga_name']); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Next of Kin Name:</strong><br> <?php echo e($biodetail->nextofKin); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Next of Kin Phone Number:</strong><br> <?php echo e($biodetail->nextofKinPhoneNo); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Next of Kin Address:</strong><br> <?php echo e($biodetail->nextofKinAddress); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Next of Kin Email:</strong><br> <?php echo e($biodetail->nextofKinEmail); ?>

                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>Next of Kin Relationship:</strong><br> <?php echo e($biodetail->nextofKinRelationship); ?>

                                  </div>
                                  <div class="mb-3 col-md-6">
                                      <strong>Course of Study:</strong><br> <?php echo e($biodetail->firstChoiceCourse['programme_option']); ?>

                                  </div>
                              </div>

                              <?php endif; ?>

                              <?php if(!empty($olevelResults)): ?>
                              <hr>
                              <h5 class="card-title mb-0"><strong>O'LEVEL RESULTS</strong></h5>
                              <hr>
                              <table class="table table-hover my-0" width="100%">
                                  <thead>
                                      <tr>
                                          <th>Exam Type</th>
                                          <th>Subject Name</th>
                                          <th>Grade</th>
                                          <th>Date Obtained</th>
                                          <th>CenterNo</th>
                                          <th>ExamNo</th>
                                          <th>Sitting</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__currentLoopData = $olevelResults->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $olevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($olevel['examName']); ?></td>
                                          <td><?php echo e($olevel['subjectName']); ?></td>
                                          <td><?php echo e($olevel['grade']); ?></td>
                                          <td><?php echo e($olevel['examMonth']); ?>, <?php echo e($olevel['examYear']); ?></td>
                                          <td><?php echo e($olevel['centerNo']); ?></td>
                                          <td><?php echo e($olevel['examNo']); ?></td>
                                          <td><?php echo e($olevel['sitting']); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                              </table>
                              <?php endif; ?>

                              <?php if(!empty($jambResults)): ?>
                              <hr>
                              <h5 class="card-title mb-0"><strong>UTME DETAILS</strong></h5>
                              <hr>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>UTME No:</strong><br> <?php echo e($jambResults['data'][0]['jambNo']); ?>

                                  </div>
                              </div>
                              <table class="table table-hover my-0" width="100%">
                                  <thead>
                                      <tr>
                                          <th>Subject</th>
                                          <th>Score</th>
                                      </tr>
                                  </thead>
                                  <tbody> <?php $utmescore=0; ?>
                                      <?php for($i = 0; $i < 4; $i++): ?>
                                          <?php
                                          $savedSubject=$jambResults['data'][$i]['subjectName'] ?? '' ;
                                          $savedScore=$jambResults['data'][$i]['jambScore'] ?? '' ;

                                          ?>
                                          <tr>
                                          <td><?php echo e($savedSubject); ?></td>
                                          <td><?php echo e($savedScore); ?></td>
                                          </tr>
                                          <?php $utmescore += $savedScore; ?>
                                          <?php endfor; ?>
                                  </tbody>
                              </table>
                              <br>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <strong>UTME Score:</strong> <?php echo e($utmescore); ?>

                                  </div>
                              </div>
                              <?php endif; ?>

                              <?php if(!empty($schoolDetails)): ?>
                              <hr>
                              <h5 class="card-title mb-0"><strong>SCHOOL ATTENDED</strong></h5>
                              <hr>
                              <table class="table table-hover my-0" width="100%" style="font-size:12px">
                                  <thead>
                                      <tr>
                                          <th>School Name</th>
                                          <th>Registration No</th>
                                          <th>Course</th>
                                          <th>From</th>
                                          <th>To</th>
                                      </tr>
                                  </thead>
                                  <tbody>

                                      <tr>
                                          <td><?php echo e($schoolDetails['data'][0]['schoolName']); ?></td>
                                          <td><?php echo e($schoolDetails['data'][0]['ndMatno']); ?></td>
                                          <td><?php echo e($schoolDetails['data'][0]['courseofStudy']); ?></td>
                                          <td><?php echo e($schoolDetails['data'][0]['fromDate']); ?></td>
                                          <td><?php echo e($schoolDetails['data'][0]['toDate']); ?></td>
                                      </tr>

                                  </tbody>
                              </table>
                              <?php endif; ?>

                              <?php if($certificates->status != 'error'): ?>
                              <hr>
                              <h5 class="card-title mb-0"><strong>CERTIFICATES UPLOADED</strong></h5>
                              <hr>
                              <table class="table table-hover my-0" width="100%" style="font-size:12px">

                                  <tbody>


                                      <tr style="font-size: 14px;">
                                          <td><?php echo e(implode(', ', array_column($certificates->data, 'documentName'))); ?></td>
                                      </tr>


                                  </tbody>
                              </table>
                              <?php endif; ?>

                              <hr>
                              <h5 class="card-title mb-0"><strong>DECLARATION</strong></h5>
                              <hr>
                              <p>
                                  <?php echo $declaration['data']['declarationtext']; ?>

                              </p>

                              <?php if(!$applicantStatus['applicationSubmit']): ?>
                              <form action="<?php echo e(route('admissions.declaration')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <button type="submit" class="btn btn-success"
                                      onclick="return confirm('You have accepted the declaration and your application will be submitted.')">
                                      <i class="fas fa-check"></i> Accept Declaration and Submit Application
                                  </button>
                              </form>
                              <?php else: ?>
                              <div class="alert alert-success alert-dismissible" role="alert">
                                  <div class="alert-message">
                                      <strong>Congratulation!</strong> Your Application has been Submitted.
                                  </div>
                              </div>
                              <?php endif; ?>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
  </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/declaration.blade.php ENDPATH**/ ?>