<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal Login - <?php echo e($schoolName->schoolname); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .login-container {
            max-width: 500px;
            margin: 0 auto;
            padding: 10px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 5px;
        }

        .login-header {
            margin-bottom: 20px;
            text-align: center;
        }

        .login-header img {
            max-width: 100px;
        }

        .login-header h1 {
            margin-top: 10px;
        }

        .login-footer {
            text-align: center;
            margin-top: 20px;
        }

        .portal-label {
            font-weight: bold;
            /* Makes the label bold */
        }

        .register-link {
            text-align: right;
            margin-top: 20px;
        }

        .register-link a {
            font-size: 1em;
            color: darkblue;
            font-weight: bold;
        }

        .register-link a:hover {
            text-decoration: underline;
            color: #007bff;
        }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 10px;
            font-size: 1em;
        }

        .form-control:focus {
            border-color: #00aaff;
            box-shadow: 0 0 0 0.2rem rgba(0, 170, 255, 0.25);
        }

        .btn-orange {
            background-color: darkblue;
            border-color: blue;
            color: white;
            font-weight: bold;
        }

        .btn-orange:hover {
            background-color: blue;
            border-color: lightblue;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-container">
            <div class="login-header"><a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="School Logo"> </a>
                <h4><strong style="color:blue"><?php echo e($schoolName->schoolname); ?></strong></h4>
                <h4>
                    <p class="text-muted portal-label">Student Portal</p>
                </h4>
            </div>
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>


            <form method="POST" action="<?php echo e(route('portallogin')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="matno"><strong>Matriculation Number</strong></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['matno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="matno" name="matno" autocomplete="off" value="<?php echo e(old('matno')); ?>" required>
                    <?php $__errorArgs = ['matno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password"><strong>Password</strong></label>
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-orange btn-block">Login</button>
            </form>

            <div align="right">
                <a href="<?php echo e(url('/forgotpass')); ?>">Forgot Password</a>
            </div>


            <div class="d-flex justify-content-between">
                <div class="register-link">
                    <a href="<?php echo e(url('/')); ?>">
                        << Back to Home</a>
                </div>
                <div class="register-link">
                    <a href="<?php echo e(url('/portalverify')); ?>">Student Verification >></a>
                </div>
            </div>


            <div class="login-footer">
                <p class="text-muted">© <?php echo e(date('Y')); ?> <?php echo e($schoolName->schoolname ?? 'DPSG'); ?></p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\laragon\www\northwest\resources\views/portalLogin.blade.php ENDPATH**/ ?>