<?php $__env->startSection('title', 'Page Not Found'); ?>

<?php $__env->startSection('message'); ?>
<div class="text-center py-10">
    <h1 class="text-4xl font-bold text-red-500">404 - Page Not Found</h1>
    <p class="mt-4 text-gray-600">Oops! The page you're looking for doesn't exist.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/errors/404.blade.php ENDPATH**/ ?>