  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->

  <div class="main-content">
      <section class="section">

          <ul class="breadcrumb breadcrumb-style ">
              <li class="breadcrumb-item">

                  <h4 class="page-title m-b-0">My Profile</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i></a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>
          <?php
          //feeId = 1 for appplication form fee
          $filtered = collect($applicantPayments)->filter(fn($p) => $p['feeId'] == 1);
          $pstat = $filtered->isEmpty() ? 0 : 1;

          ?>
          <div class="row">
              <div class="col-12 col-md-6 col-lg-12">
                  <div class="card">
                      <div class="card-header">
                          <h4>Biodata</h4>
                      </div>
                      <div class="card-body">

                          <?php if(session('error')): ?>
                          <div class="alert alert-danger">
                              <?php echo e(session('error')); ?>

                          </div>
                          <?php endif; ?>
                          <?php if(session('success')): ?>
                          <div class="alert alert-success">
                              <?php echo e(session('success')); ?>

                          </div>
                          <?php endif; ?>
                          <form id="update_profile" name="update_profile"
                              action="<?php echo e(route('admissions.biodata')); ?>" method="post"
                              enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label" for="inputFirstName"><strong>Application Number</strong></label>
                                      <input type="text" class="form-control" name="app_no" value="<?php echo e($biodetail->applicationNumber); ?>" readonly>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label" for="inputLastName"><strong>Surname</strong></label>
                                      <input type="text" class="form-control" name="surname" value="<?php echo e($biodetail->surname); ?>" readonly>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label" for="inputFirstName"><strong>Firstname</strong></label>
                                      <input type="text" class="form-control" name="firstname" value="<?php echo e($biodetail->firstname); ?>" readonly>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label" for="inputLastName"><strong>Othername</strong></label>
                                      <input type="text" class="form-control" name="othernames" value="<?php echo e($biodetail->othernames); ?>" placeholder="Other name" autocomplete="off">
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Email</strong></label>
                                      <input type="text" class="form-control" name="student_email" value="<?php echo e($biodetail->studentEmail); ?>" autocomplete="off" readonly>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>GSM</strong></label>
                                      <input type="text" class="form-control" name="student_mobiletel" value="<?php echo e($biodetail->studentPhoneNo); ?>" autocomplete="off" readonly>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Course of Study</strong></label>
                                      <select id="sprog" class="form-control" disabled>
                                          <option><?php echo e($biodetail->firstChoiceCourse['programme_option'] ?? 'N/A'); ?></option>
                                      </select>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Gender</strong></label>
                                      <select name="gender" class="form-control" required>
                                          <option value="<?php echo e($biodetail->gender ?? ''); ?>"><?php echo e($biodetail->gender ?? 'Select Gender'); ?></option>
                                          <option value="Male" <?php echo e(old('gender', $biodetail->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                                          <option value="Female" <?php echo e(old('gender', $biodetail->gender) == 'Female' ? 'selected' : ''); ?>>Female</option>
                                      </select>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Programme</strong></label>
                                      <select id="sprog" class="form-control" disabled>
                                          <option><?php echo e($biodetail->programme['programme_name'] ?? 'N/A'); ?></option>
                                      </select>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Marital Status</strong></label>
                                      <select name="marital_status" class="form-control" required>
                                          <option value="<?php echo e($biodetail->maritalStatus ?? ''); ?>"><?php echo e($biodetail->maritalStatus ?? 'Select Marital Status'); ?></option>
                                          <option value="Single">Single</option>
                                          <option value="Married">Married</option>
                                          <option value="Divorced">Divorced</option>
                                          <option value="Widowed">Widowed</option>
                                      </select>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>State</strong></label>
                                      <select name="state" id="sel_state" class="form-control" required>
                                          <option value="<?php echo e($biodetail->stateofOrigin['state_id'] ?? ''); ?>"><?php echo e($biodetail->stateofOrigin['state_name'] ?? 'Select State'); ?></option>
                                          <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($state['state_id']); ?>"><?php echo e($state['state_name']); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>LGA</strong></label>
                                      <select name="lga" id="sel_lga" class="form-control" required>
                                          <option value="<?php echo e($biodetail->lga['lga_id'] ?? ''); ?>"><?php echo e($biodetail->lga['lga_name'] ?? 'Select LGA'); ?></option>
                                      </select>
                                  </div>
                              </div>

                              <script>
                                  document.getElementById('sel_state').addEventListener('change', function() {
                                      const stateId = this.value;
                                      const lgaSelect = document.getElementById('sel_lga');

                                      if (stateId) {
                                          fetch("<?php echo e(url('/api/v1/getlga')); ?>", {
                                                  method: 'POST',
                                                  headers: {
                                                      'Content-Type': 'application/x-www-form-urlencoded'
                                                  },
                                                  body: new URLSearchParams('stateId=' + stateId)
                                              })
                                              .then(response => response.json())
                                              .then(data => {
                                                  lgaSelect.innerHTML = '<option value="">Select LGA</option>';
                                                  data['data'].forEach(lga => {
                                                      const option = document.createElement('option');
                                                      option.value = lga.lga_id;
                                                      option.text = lga.lga_name;
                                                      lgaSelect.add(option);
                                                  });
                                              })
                                              .catch(error => console.error('Error fetching LGAs:', error));
                                      } else {
                                          lgaSelect.innerHTML = '<option value="">Select State of Origin</option>';
                                      }
                                  });
                              </script>


                              <div class="row">
                                  <?php $hasBirthDate = !empty($biodetail->birthDate); ?>
                                  <div class="mb-3 col-md-4">
                                      <label class="form-label"><strong>Day of Birth</strong></label>
                                      <select name="dob" class="form-control" required>
                                          <option value="<?php echo e($hasBirthDate ? date('d', strtotime($biodetail->birthDate)) : ''); ?>"><?php echo e($hasBirthDate ? date('d', strtotime($biodetail->birthDate)) : 'Select Day'); ?></option>
                                          <?php for($day = 1; $day <= 31; $day++): ?>
                                              <?php $val=str_pad($day, 2, '0' , STR_PAD_LEFT); ?>
                                              <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                                              <?php endfor; ?>
                                      </select>
                                  </div>
                                  <div class="mb-3 col-md-4">
                                      <label class="form-label"><strong>Month of Birth</strong></label>
                                      <select name="mob" class="form-control" required>
                                          <option value="<?php echo e($hasBirthDate ? date('m', strtotime($biodetail->birthDate)) : ''); ?>"><?php echo e($hasBirthDate ? date('M', strtotime($biodetail->birthDate)) : 'Select Month'); ?></option>
                                          <?php
                                          $months = [
                                          '01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr',
                                          '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug',
                                          '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec'
                                          ];
                                          ?>
                                          <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($num); ?>"><?php echo e($name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>
                                  <div class="mb-3 col-md-4">
                                      <label class="form-label"><strong>Year of Birth</strong></label>
                                      <select name="yob" class="form-control" required>
                                          <option value="<?php echo e($hasBirthDate ? date('Y', strtotime($biodetail->birthDate)) : ''); ?>"><?php echo e($hasBirthDate ? date('Y', strtotime($biodetail->birthDate)) : 'Select Year'); ?></option>
                                          <?php for($year = now()->year; $year >= 1970; $year--): ?>
                                          <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                          <?php endfor; ?>
                                      </select>
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Permanent Home Address</strong></label>
                                      <input type="text" class="form-control" name="student_homeaddress"
                                          value="<?php echo e(old('student_homeaddress', $biodetail->studentHomeAddress)); ?>"
                                          placeholder="Permanent Home Address" required autocomplete="off">
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Contact Address</strong></label>
                                      <input type="text" class="form-control" name="contact_address"
                                          value="<?php echo e(old('contact_address', $biodetail->contactAddress)); ?>"
                                          placeholder="Contact Address" required autocomplete="off">
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Next of Kin Name</strong></label>
                                      <input type="text" class="form-control" name="nok"
                                          value="<?php echo e(old('nok', $biodetail->nextofKin)); ?>"
                                          placeholder="Next of Kin Name" required autocomplete="off">
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Next of Kin Phone Number</strong></label>
                                      <input type="number" class="form-control" name="nok_tel"
                                          value="<?php echo e(old('nok_tel', $biodetail->nextofKinPhoneNo)); ?>"
                                          placeholder="Next of Kin Phone Number" required autocomplete="off">
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Next of Kin Address</strong></label>
                                      <input type="text" class="form-control" name="nok_address"
                                          value="<?php echo e(old('nok_address', $biodetail->nextofKinAddress)); ?>"
                                          placeholder="Next of Kin Address" required autocomplete="off">
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Next of Kin Email Address</strong></label>
                                      <input type="email" class="form-control" name="nok_email"
                                          value="<?php echo e(old('nok_email', $biodetail->nextofKinEmail)); ?>"
                                          placeholder="Next of Kin Email Address" required autocomplete="off">
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Next of Kin Relationship</strong></label>
                                      <input type="text" class="form-control" name="nok_rel"
                                          value="<?php echo e(old('nok_rel', $biodetail->nextofKinRelationship)); ?>"
                                          placeholder="Next of Kin Relationship" required autocomplete="off">
                                  </div>

                                  <div class="mb-3 col-md-6">
                                      <label class="form-label"><strong>Home Town / Village</strong></label>
                                      <input type="text" class="form-control" name="hometown"
                                          value="<?php echo e(old('hometown', $biodetail->homeTown)); ?>"
                                          placeholder="Home Town / Village" required autocomplete="off">
                                  </div>
                              </div>
                              <div class="row">
                                  <?php if($biodetail->profilePicture === 'avatar.jpg'): ?>
                                  <div class="mb-3 col-md-12">
                                      <label class="form-label"><strong>Upload Passport (Max. size 100kb, Allowed: .jpg, .jpeg)</strong></label>
                                      <input type="file" class="form-control" name="file" required accept="image/jpeg, image/jpg">
                                      <input type="hidden" class="form-control" name="updatePassport" required value="1">
                                  </div>

                                  <div class="mb-3 col-md-12 alert alert-warning alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>Warning!</strong> Confirm your profile information before saving
                                      </div>
                                  </div>

                                  <?php if($pstat == 1): ?>
                                  <div class="mb-3 col-md-12">
                                      <button type="submit" class="btn btn-primary">Confirm and Save Biodata</button>
                                  </div>
                                  <?php else: ?>
                                  <div class="alert alert-danger alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>APPLICATION FEE PAYMENT</strong> NOT MADE.
                                      </div>
                                  </div>
                                  <?php endif; ?>
                                  <?php else: ?>
                                  <div class="alert alert-info alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>Info!</strong> Passport Photo already Uploaded.
                                      </div>
                                  </div>

                                  <div class="mb-3 col-md-12">
                                      <button type="submit" class="btn btn-primary">Update Biodata</button>

                                      <?php if($applicantStatus['biodata'] == 1 ): ?>
                                      <a href="<?php echo e(route('admissions.olevel')); ?>" class="btn btn-success">
                                          Proceed to add Olevel Result</a>
                                      <?php endif; ?>
                                  </div>
                                  <?php endif; ?>


                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/profile.blade.php ENDPATH**/ ?>