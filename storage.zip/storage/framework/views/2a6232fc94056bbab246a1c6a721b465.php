  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">

          <ul class="breadcrumb breadcrumb-style">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">School Attended</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i>
                  </a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>

          <div class="col-md-9 col-xl-12">
              <div class="tab-content">
                  <div class="tab-pane fade show active" id="application" role="tabpanel">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title mb-0"><strong>SCHOOL ATTENDED AND DATE </strong></h5>
                              <hr>
                              <form name="add_school" action="<?php echo e(route('admissions.school')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <div class="row">
                                      <div class="mb-3 col-md-12">
                                          <label class="form-label"><strong>Name of School</strong></label>
                                          <input type="text" class="form-control" name="schoolName" autocomplete="off"
                                              value="<?php echo e($schoolDetails['data'][0]['schoolName'] ?? ''); ?>">
                                      </div>

                                      <div class="mb-3 col-md-12" id="othercolor">
                                          <label class="form-label"><strong>Registration No</strong></label>
                                          <input type="text" class="form-control" name="ndMatno" autocomplete="off"
                                              value="<?php echo e($schoolDetails['data'][0]['ndMatno'] ?? ''); ?>">
                                      </div>

                                      <div class="mb-3 col-md-6">
                                          <label class="form-label"><strong>Course</strong></label>
                                          <input type="text" class="form-control" name="courseofstudy" autocomplete="off"
                                              value="<?php echo e($schoolDetails['data'][0]['courseofStudy'] ?? ''); ?>">
                                      </div>

                                      <div class="mb-3 col-md-6">
                                          <label class="form-label"><strong>Grade</strong></label>
                                          <select name="grade" class="form-control" required>
                                              <option value="">Select Grade</option>
                                              <?php $__currentLoopData = ['Distinction', 'Upper Credit', 'Lower Credit', 'Pass']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($grade); ?>" <?php echo e((strtolower($grade) == strtolower($schoolDetails['data'][0]['grade'] ?? '')) ? 'selected' : ''); ?>>
                                                  <?php echo e($grade); ?>

                                              </option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                      </div>

                                      <div class="mb-3 col-md-6">
                                          <label class="form-label"><strong>From</strong></label>
                                          <select name="fromDate" class="form-control" required>
                                              <option value="">Select Year</option>
                                              <?php for($year = now()->year; $year >= 1980; $year--): ?>
                                              <option value="<?php echo e($year); ?>" <?php echo e((isset($schoolDetails['data'][0]['fromDate']) && $schoolDetails['data'][0]['fromDate'] == $year) ? 'selected' : ''); ?>>
                                                  <?php echo e($year); ?>

                                              </option>
                                              <?php endfor; ?>
                                          </select>
                                      </div>

                                      <div class="mb-3 col-md-6">
                                          <label class="form-label"><strong>To</strong></label>
                                          <select name="toDate" class="form-control" required>
                                              <option value="">Select Year</option>
                                              <?php for($year = now()->year; $year >= 1980; $year--): ?>
                                              <option value="<?php echo e($year); ?>" <?php echo e((isset($schoolDetails['data'][0]['toDate']) && $schoolDetails['data'][0]['toDate'] == $year) ? 'selected' : ''); ?>>
                                                  <?php echo e($year); ?>

                                              </option>
                                              <?php endfor; ?>
                                          </select>
                                      </div>
                                      <?php if($applicantStatus['jambResult'] == 1 ): ?>
                                      <div class="mb-3 col-md-12">
                                          <button class="btn btn-success"><i class="fas fa-check"></i> Save School Details</button>
                                      </div>
                                      <?php else: ?>
                                      <div class="alert alert-danger alert-dismissible" role="alert">
                                          <div class="alert-message">
                                              <strong>JAMB RESULTS </strong> NOT YET SAVED.
                                          </div>
                                      </div>
                                      <?php endif; ?>
                                  </div>
                              </form>

                              <br />

                          </div>
                      </div> <?php if(!empty($schoolDetails['data'])): ?>
                      <a href="<?php echo e(route('admissions.certupload')); ?>" class="btn btn-info">
                          <i class="fas fa-info"></i> Click here to Save and Continue
                      </a>
                      <?php endif; ?>
                  </div>
              </div>
          </div>
      </section>
  </div>



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/schoolattended.blade.php ENDPATH**/ ?>