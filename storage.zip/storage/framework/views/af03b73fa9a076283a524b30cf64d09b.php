  

  <?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-12 col-sm-12 offset-sm-1 col-md-12 offset-md-2 col-lg-12 offset-lg-2 col-xl-6 offset-xl-3">
          <div class="login-brand">
              <div align="center">
                  <a href="<?php echo e(route('admissions')); ?>">
                      <picture>
                          <source media="(max-width: 799px)" srcset="<?php echo e(asset('public/assets/img/delta.png')); ?>">
                          <source media="(min-width: 800px)" srcset="<?php echo e(asset('public/assets/img/delta.png')); ?>">
                          <img src="<?php echo e(asset('public/assets/img/delta.png')); ?>" alt="School Logo" class="responsive-img valign profile-image-login">
                      </picture>

                  </a>
              </div>

          </div>
          <div class="row">

              <div class="col-12 col-sm-12 col-lg-12">

                  <div class="card card-primary">
                      <div>
                          
                          <?php if(session('success')): ?>
                          <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                          <?php endif; ?>

                          <?php if(session('error')): ?>
                          <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                          <?php endif; ?>
                      </div>
                      <div class="card-header">
                          <h4>Create Account

                          </h4>

                      </div>

                      <form id="add_create" name="add_create" action="<?php echo e(route('admissions.store')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <div class="card-body">
                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-user"></i></div>
                                      </div>
                                      <input name="surname" class="form-control <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Surname" required autocomplete="off" value="<?php echo e(old('surname')); ?>">
                                  </div>
                                  <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-user-plus"></i></div>
                                      </div>
                                      <input name="firstname" type="text" class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Firstname" required autocomplete="off" value="<?php echo e(old('firstname')); ?>">
                                  </div>
                                  <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-user-alt"></i></div>
                                      </div>
                                      <input name="othernames" type="text" class="form-control <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Othernames" autocomplete="off" value="<?php echo e(old('othernames')); ?>">
                                  </div>
                                  <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-school"></i></div>
                                      </div>
                                      <select name="progtype" id="sprogtype" class="form-control <?php $__errorArgs = ['progtype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                                      </select>

                                      <script>
                                          const BASE_URL = "<?php echo e(config('app.url')); ?>";
                                          document.addEventListener('DOMContentLoaded', function() {
                                              const select = document.getElementById('sprogtype');

                                              // Clear existing and add default option
                                              select.innerHTML = `<option value="">Select Programme Type</option>`;

                                              fetch(`${BASE_URL}/api/v1/programme-types`)
                                                  .then(response => {
                                                      if (!response.ok) throw new Error('Failed to fetch programme types');
                                                      return response.json();
                                                  })
                                                  .then(data => {
                                                      const programmeTypeList = data.data ?? [];

                                                      programmeTypeList.forEach(prog => {
                                                          const option = document.createElement('option');
                                                          option.value = prog.programmet_id;
                                                          option.textContent = prog.programmet_name;
                                                          select.appendChild(option);
                                                      });
                                                  })
                                                  .catch(error => {
                                                      console.error('Error loading programme types:', error);
                                                  });
                                          });
                                      </script>

                                  </div> <?php $__errorArgs = ['progtype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <span class="input-group-text"><i class="fas fa-university"></i></span>
                                      </div>
                                      <select name="prog" id="sel_prog" class="form-control <?php $__errorArgs = ['prog'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                      </select>

                                      <script>
                                          document.addEventListener('DOMContentLoaded', function() {
                                              const select = document.getElementById('sel_prog');

                                              // Clear existing and add default option
                                              select.innerHTML = `<option value="">Select Programme </option>`;

                                              fetch(`${BASE_URL}/api/v1/programmes`)
                                                  .then(response => {
                                                      if (!response.ok) throw new Error('Failed to fetch programmes');
                                                      return response.json();
                                                  })
                                                  .then(data => {
                                                      const programmeList = data.data ?? [];

                                                      programmeList.forEach(prog => {
                                                          const option = document.createElement('option');
                                                          option.value = prog.programme_id;
                                                          option.textContent = prog.programme_name;
                                                          select.appendChild(option);
                                                      });
                                                  })
                                                  .catch(error => {
                                                      console.error('Error loading programme:', error);
                                                  });
                                          });
                                      </script>
                                  </div>
                                  <?php $__errorArgs = ['prog'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-school"></i></div>
                                      </div>
                                      <select name="cos_id" id="sel_cos" class="form-control <?php $__errorArgs = ['cos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                          <option value="">Select Course of Study - First Choice</option>
                                      </select>
                                  </div>
                                  <?php $__errorArgs = ['cos_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-school"></i></div>
                                      </div>
                                      <select name="cos_id_two" id="sel_cos_two" class="form-control <?php $__errorArgs = ['cos_id_two'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                          <option value="">Select Course of Study - Second Choice</option>
                                      </select>
                                  </div>
                                  <?php $__errorArgs = ['cos_id_two'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <script>
                                  function updateCourseOptions(selectId, progId, progTypeId, optionText) {
                                      const cosSelect = document.getElementById(selectId);
                                      cosSelect.innerHTML = `<option value="">${optionText}</option>`;

                                      if (progId && progTypeId) {
                                          const url = `${BASE_URL}/api/v1/courses-of-study/${progId}/${progTypeId}`;

                                          fetch(url)
                                              .then(response => {
                                                  if (!response.ok) throw new Error('Network response was not ok');
                                                  return response.json();
                                              })
                                              .then(data => {
                                                  const courseList = data.data ?? [];

                                                  cosSelect.innerHTML = `<option value="">${optionText}</option>`;

                                                  courseList.forEach(cos => {
                                                      const option = document.createElement('option');
                                                      option.value = cos.do_id;
                                                      option.text = cos.programme_option;
                                                      cosSelect.appendChild(option);
                                                  });
                                              })
                                              .catch(error => console.error('Error fetching Course of Study:', error));
                                      }
                                  }

                                  document.getElementById('sprogtype').addEventListener('change', function() {
                                      const sprogTypeId = this.value;

                                      const selProg = document.getElementById('sel_prog');
                                      const selCos = document.getElementById('sel_cos');
                                      const selCosTwo = document.getElementById('sel_cos_two');

                                      selProg.value = '';
                                      selCos.innerHTML = '<option value="">Select Course of Study - First Choice</option>';
                                      selCosTwo.innerHTML = '<option value="">Select Course of Study - Second Choice</option>';

                                      selProg.addEventListener('change', function() {
                                          const progId = this.value;

                                          selCos.innerHTML = '<option value="">Select Course of Study - First Choice</option>';
                                          selCosTwo.innerHTML = '<option value="">Select Course of Study - Second Choice</option>';

                                          setTimeout(function() {
                                              updateCourseOptions('sel_cos', progId, sprogTypeId, 'Select First Choice');
                                              updateCourseOptions('sel_cos_two', progId, sprogTypeId, 'Select Second Choice');
                                          }, 200); // Reduced to 200ms or remove if unnecessary
                                      });
                                  });
                              </script>



                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                      </div>
                                      <input name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required data-indicator="pwindicator">
                                  </div>
                                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-at"></i></div>
                                      </div>
                                      <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Address" required autocomplete="off" value="<?php echo e(old('email')); ?>">
                                  </div>
                                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-phone"></i></div>
                                      </div>
                                      <input name="phoneno" type="number" class="form-control <?php $__errorArgs = ['phoneno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Phone Number" required autocomplete="off" value="<?php echo e(old('phoneno')); ?>">
                                  </div>
                                  <?php $__errorArgs = ['phoneno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                              <div class="form-group">
                                  <div class="input-group mb-2">
                                      <div class="input-group-prepend">
                                          <div class="input-group-text"><i class="fas fa-user-lock"></i></div>
                                      </div>
                                      <input type="number" class="form-control <?php $__errorArgs = ['captchaResult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="captchaResult"
                                          placeholder="Solve the Math: <?php echo e($random_number1); ?> + <?php echo e($random_number2); ?> =" required autocomplete="off">
                                  </div>
                                  <?php $__errorArgs = ['captchaResult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="text-danger small"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  <input type="hidden" name="first_number" value="<?php echo e($random_number1); ?>">
                                  <input type="hidden" name="second_number" value="<?php echo e($random_number2); ?>">
                              </div>

                              <div align="center">
                                  <button class="btn btn-primary btn-lg btn-block" type="submit">Create Account</button>
                              </div>

                              <br />
                              <div class="float-right">
                                  <a href="<?php echo e(route('admissions')); ?>"><strong>&lt;&lt; Back to Home</strong></a>
                              </div>
                          </div>
                      </form>


                  </div>
                  <div align="center" class="example5">
                      <marquee> <?php echo e($schoolInfo['appmarque']); ?> </marquee>
                  </div>

              </div>

          </div>

      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.admlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/start.blade.php ENDPATH**/ ?>