  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">
          <ul class="breadcrumb breadcrumb-style">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">UTME Results</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i>
                  </a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>

          <div class="container-fluid p-0">
              <div class="row">
                  <div class="col-md-9 col-xl-12">
                      <div class="tab-content">
                          <div class="tab-pane fade show active" id="application" role="tabpanel">
                              <div class="card">
                                  <div class="card-body">
                                      <strong>ADD UTME RESULT DETAILS</strong>
                                      <hr />

                                      <form name="add_jamb" action="<?php echo e(route('admissions.jamb')); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <div class="row">
                                              <div class="mb-3 col-md-12">
                                                  <label class="form-label" for="jambno"><strong>UTME No</strong></label>
                                                  <input name="jambNo" type="text" class="form-control" id="jambno"
                                                      value="<?php echo e($jambResults['data'][0]['jambNo'] ?? ''); ?>"
                                                      autocomplete="off" required placeholder="Enter UTME No" minlength="14" maxlength="14">
                                              </div>

                                              <div class="col-lg-12">
                                                  <div class="alert alert-light">UTME SUBJECTS & SCORE</div>
                                              </div>

                                              <?php for($i = 0; $i < 4; $i++): ?>
                                                  <?php
                                                  $savedSubject=$jambResults['data'][$i]['subjectName'] ?? '' ;
                                                  $savedScore=$jambResults['data'][$i]['jambScore'] ?? '' ;
                                                  ?>

                                                  <div class="mb-1 col-md-6">
                                                  <select name="subjectName[]" id="subject<?php echo e($i + 1); ?>" class="form-control" required>
                                                      <option value="">Select Subject</option>
                                                      <?php $__currentLoopData = $olevelSubjects['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <option value="<?php echo e($subject['subjectname']); ?>"
                                                          <?php echo e($subject['subjectname'] == $savedSubject ? 'selected' : ''); ?>>
                                                          <?php echo e($subject['subjectname']); ?>

                                                      </option>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </select>
                                          </div>

                                          <div class="mb-1 col-md-6">
                                              <input type="number" class="form-control" name="jambScore[]" autocomplete="off"
                                                  value="<?php echo e($savedScore); ?>" required placeholder="Enter Score" min="1" max="100">
                                          </div>
                                          <?php endfor; ?>
                                  </div>
                                  <br> <?php if($applicantStatus['olevels'] == 1 ): ?>
                                  <button class="btn btn-success"><i class="fas fa-check"></i> Save UTME Results</button>
                                  <?php else: ?>
                                  <div class="alert alert-danger alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>OLEVEL RESULTS </strong> NOT YET SAVED.
                                      </div>
                                  </div>
                                  <?php endif; ?>

                                  </form>


                              </div>
                          </div>

                          <?php if(!empty($jambResults['data'])): ?>
                          <a href="<?php echo e(route('admissions.school')); ?>" class="btn btn-info">
                              <i class="fas fa-info"></i> Click here to Save and Continue
                          </a>
                          <?php endif; ?>
                      </div>
                  </div>
              </div>
          </div>
  </div>
  </section>
  </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/jamb.blade.php ENDPATH**/ ?>