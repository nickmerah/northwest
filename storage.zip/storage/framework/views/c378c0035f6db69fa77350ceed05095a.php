<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($SCHOOLNAME); ?> - Application Portal</title>

    <style>
        body,

        html {

            margin: 0;

            padding: 0;

            height: 100%;

            width: 100%;

        }



        .watermarked-page {

            position: relative;

            width: 100%;

            height: 100vh;

            /* Full viewport height */

            padding: 20px;

            /* Adjust as needed */

            box-sizing: border-box;

        }



        .watermarked-page .watermark {

            position: absolute;

            top: 0;

            left: 0;

            width: 100%;

            height: 100%;

            pointer-events: none;

            opacity: 0.1;

            background: url("<?php echo e(asset('public/assets/img/logo.png')); ?>") no-repeat center center;

            background-size: 40% auto;

        }



        .content {

            position: relative;

            z-index: 1;

        }



        table {

            width: 100%;

            border-collapse: collapse;

            font-size: large;

        }



        th,

        td {

            border: 1px solid #ddd;

            padding: 10px;

        }



        th {

            background-color: #f2f2f2;

        }



        .table-image-cell {

            text-align: right;

            vertical-align: middle;

        }



        .table-image-cell img {

            display: inline-block;

        }



        .table {

            width: 100%;

            table-layout: fixed;

        }



        .table td {

            padding: 8px;

        }
    </style>



    <script language="JavaScript" type="text/JavaScript">

        function MM_openBrWindow(theURL,winName,features) { //v2.0

  window.open(theURL,winName,features);

}







</script>

    <script>
        function printWindow() {



            bV = parseInt(navigator.appVersion)



            if (bV >= 4) window.print()



        }
    </script>

</head>



<body>



    <div class="watermarked-page">

        <div class="watermark">

        </div>

        <?php if(isset($paymentData) && count($paymentData) > 0): ?>
        <?php $__currentLoopData = $paymentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paydetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="content">
            <div align="center"><br>
                <img src="<?php echo e(asset('public/assets/img/logo.png')); ?>" alt="dspg" width="120" height="131">
                <br>
                <h2><?php echo e(strtoupper($SCHOOLNAME)); ?></h2>
                <h3><u><?php echo e(strtoupper($paydetail['feeName'])); ?> - Payment Receipt</u></h3>
            </div>

            <div class="card-body">
                <br>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td style="width: 25%;"><strong>Application No:</strong></td>
                            <td style="width: 50%;"><?php echo e($paydetail['applicationNo']); ?></td>
                            <td rowspan="3" class="table-image-cell" style="width: 25%;">
                                <img alt="Photo" src="<?php echo e($passportUrl); ?>" class="rounded-circle img-responsive mt-3" width="135" height="131" />
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Fullnames:</strong></td>
                            <td><strong><?php echo e($paydetail['fullNames']); ?></strong></td>
                        </tr>

                        <tr>
                            <td><strong>Fee Name:</strong></td>
                            <td><?php echo e($paydetail['feeName']); ?></td>
                        </tr>

                        <tr>
                            <td><strong>Transaction ID:</strong></td>
                            <td colspan="2"><?php echo e($paydetail['transactionID']); ?></td>
                        </tr>

                        <tr>
                            <td><strong>Session:</strong></td>
                            <td colspan="2">
                                <?php echo e($paydetail['sessionPaid']); ?> / <?php echo e($paydetail['sessionPaid'] + 1); ?>

                            </td>
                        </tr>

                        <tr>
                            <td><strong>Amount:</strong></td>
                            <td colspan="2">&#8358;<?php echo e(number_format($paydetail['amount'])); ?></td>
                        </tr>

                        <tr>
                            <td><strong>Date:</strong></td>
                            <td colspan="2">
                                <?php echo e(\Carbon\Carbon::parse($paydetail['datePaid'])->format('d-M-Y')); ?>

                            </td>
                        </tr>

                        <tr>
                            <td><strong>Status:</strong></td>
                            <td colspan="2"><strong><?php echo e(strtoupper($paydetail['paymentStatus'])); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <p class="text-center mt-4">No payment receipt found.</p>
        <?php endif; ?>


    </div>

    </div>


    <script>
        printWindow()
    </script>
</body>

</html><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/receipt.blade.php ENDPATH**/ ?>