<?php $__env->startSection('content'); ?>
<h2>Upload Passport</h2>
<hr>
<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php endif; ?>

<form method="POST" action="<?php echo e(route('updatepassport')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="passport"><strong>Passport</strong></label>
        <input type="file" class="form-control" name="passport" id="passport" accept=".jpg,.jpeg" required>
    </div>

    <?php
    $photoPath = storage_path('app/public/passport/' . $student->std_photo);
    ?>
    <?php if(!file_exists($photoPath)): ?>
    <button type="submit" class="btn btn-orange btn-block">Update Passport</button>
    <?php endif; ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/portal/passport.blade.php ENDPATH**/ ?>