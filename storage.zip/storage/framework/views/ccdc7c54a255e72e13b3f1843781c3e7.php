  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->

  <div class="main-content">
      <section class="section">

          <ul class="breadcrumb breadcrumb-style ">
              <li class="breadcrumb-item">

                  <h4 class="page-title m-b-0">e-Payment History</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i></a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>
          <div class="invoice">
              <div class="invoice-print">
                  <div class="col-md-12">
                      <div class="section-title">Payment History</div>

                      <div class="table-responsive">
                          <table class="table table-striped table-hover table-md">
                              <tr>
                                  <th class="text-center">Fee Name</th>
                                  <th class="text-center">Transaction ID</th>
                                  <th class="text-center">Amount</th>
                                  <th class="text-center">Date Paid</th>
                                  <th class="text-center">Action</th>
                              </tr>

                              <?php $__empty_1 = true; $__currentLoopData = $paymentDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tr>
                                  <td class="text-center"><?php echo e($paymentData['feeName'] ?? '-'); ?></td>
                                  <td class="text-center"><?php echo e($paymentData['transactionID'] ?? '-'); ?></td>
                                  <td class="text-center">₦<?php echo e(number_format($paymentData['amount'] ?? 0)); ?></td>
                                  <td class="text-center"><?php echo e($paymentData['datePaid'] ?? '-'); ?></td>
                                  <td class="text-center">
                                      <a href="<?php echo e(route('admissions.receipt', $paymentData['transactionID'])); ?>" class="btn btn-success" target="_blank">
                                          <i class="fas fa-print"></i> Print Receipt
                                      </a>
                                  </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                  <td class="text-center" colspan="5">No payment record found.</td>
                              </tr>
                              <?php endif; ?>
                          </table>

                      </div>

                  </div>
              </div>
          </div>
          <a href="<?php echo e(route('admissions.checkpayment')); ?>" class="btn btn-info"><i class="fas fa-dollar-sign"></i> Check Payment Status</a>
          <hr>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/epaymenthistory.blade.php ENDPATH**/ ?>