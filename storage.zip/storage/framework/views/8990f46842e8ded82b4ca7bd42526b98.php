  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <div class="main-content">
      <section class="section">
          <ul class="breadcrumb breadcrumb-style">
              <li class="breadcrumb-item">
                  <h4 class="page-title m-b-0">Certificates Upload</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(url('applicant')); ?>">
                      <i class="fas fa-home"></i>
                  </a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>

          <div class="col-md-9 col-xl-12">
              <div class="tab-content">
                  <div class="tab-pane fade show active" id="application" role="tabpanel">
                      <div class="card">
                          <div class="card-body">
                              <?php if(session('success')): ?>
                              <div class="alert alert-success">
                                  <?php echo e(session('success')); ?>

                              </div>
                              <?php endif; ?>

                              <?php if(session('error')): ?>
                              <div class="alert alert-danger">
                                  <?php echo e(session('error')); ?>

                              </div>
                              <?php endif; ?>

                              <?php if($certificates->status != 'error'): ?>

                              <table class="table table-bordered" style="font-size: 13px;">
                                  <thead>
                                      <tr>
                                          <th>DOCUMENT NAME</th>
                                          <th>ACTION</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__currentLoopData = $certificates->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($docs['documentName']); ?></td>
                                          <td>
                                              <a href="<?php echo e(Storage::disk('public')->url('app/public/documents/' . $docs['uploadName'])); ?>" target="_blank">
                                                  View Document
                                              </a>
                                          </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                              </table>
                              <br>
                              <a class="btn btn-danger"
                                  href="<?php echo e(route('admissions.removecert')); ?>"
                                  onclick="return confirm('Are you sure you want to re-upload the documents? This will remove any existing uploaded documents.');">
                                  ReUpload Documents
                              </a>
                              <?php else: ?>
                              <hr />
                              <strong>UPLOAD DOCUMENT</strong>

                              <div class="alert alert-warning">
                                  <strong>File Upload Guidelines:</strong>
                                  <ul>
                                      <li>Only PDF files are allowed.</li>
                                      <li>Minimum file size: 100KB.</li>
                                  </ul>
                              </div>
                              <hr />

                              <form name="addcert" action="<?php echo e(route('admissions.certupload')); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <div class="row">

                                      <div class="mb-3 col-md-12">
                                          <label class="form-label"><strong>O’ Level Result (If you have 2 results, combine in one file)</strong></label>
                                          <input name="o_level_result" type="file" class="form-control" required accept=".pdf">
                                      </div>
                                      <div class="mb-3 col-md-12">
                                          <label class="form-label"><strong>Jamb Result</strong></label>
                                          <input name="jamb_result" type="file" class="form-control" required accept=".pdf">
                                      </div>
                                      <div class="mb-3 col-md-12">
                                          <label class="form-label"><strong>Birth Certificate</strong></label>
                                          <input name="birth_certificate" type="file" class="form-control" required accept=".pdf">
                                      </div>
                                  </div>
                                  <?php if($applicantStatus['schoolattended'] == 1 ): ?>
                                  <button type="submit" class="btn btn-primary">Upload Documents</button>
                                  <?php else: ?>
                                  <div class="alert alert-danger alert-dismissible" role="alert">
                                      <div class="alert-message">
                                          <strong>SCHOOL ATTENDED </strong> NOT YET SAVED.
                                      </div>
                                  </div>
                                  <?php endif; ?>
                              </form>
                              <?php endif; ?>
                          </div>
                      </div><?php if($certificates->status != 'error'): ?>
                      <a href="<?php echo e(route('admissions.declaration')); ?>" class="btn btn-info">
                          <i class="fas fa-info"></i> Click here to Save and Continue
                      </a>
                      <?php endif; ?>
                  </div>
              </div>
          </div>
      </section>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/uploadcertificate.blade.php ENDPATH**/ ?>