  

  <?php $__env->startSection('content'); ?>

  <!-- Main Content -->

  <div class="main-content">
      <section class="section">

          <ul class="breadcrumb breadcrumb-style ">
              <li class="breadcrumb-item">

                  <h4 class="page-title m-b-0">e-Payment Slip</h4>
              </li>
              <li class="breadcrumb-item">
                  <a href="<?php echo e(route('admissions.dashboard')); ?>">
                      <i class="fas fa-home"></i></a>
              </li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ul>
          <div class="invoice">
              <div class="invoice-print">

                  <div class="row">
                      <div class="col-lg-12">
                          <div class="invoice-title">
                              <h2>e-Invoice - <?php echo e($paymentData->paymentDetails['paymentStatus']); ?></h2>

                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-6">
                                  <address>
                                      <strong>Billed To:</strong><br>
                                      <strong> <?php echo e($paymentData->paymentDetails['fullNames']); ?></strong><br>
                                      <?php echo e($paymentData->paymentDetails['applicationNo']); ?> <br>
                                      TransactionID: <b> <?php echo e($paymentData->paymentDetails['transactionID']); ?> </b><br>
                                      <?php echo e($paymentData->paymentDetails['appYear']); ?> / <?php echo e($paymentData->paymentDetails['appYear'] + 1); ?> Session
                                  </address>
                              </div>
                              <div class="col-md-6 text-md-right">
                                  <address>
                                      <strong>From:</strong><br>
                                      <?php echo e($SCHOOLNAME); ?><br>
                                  </address>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-6">
                                  <address>
                                      <strong>Generated Date:</strong><br>
                                      <?php echo e(date('d-M-Y', strtotime($paymentData->paymentDetails['transactionDate']))); ?>

                                  </address>
                              </div>

                          </div>
                      </div>
                  </div>
                  <div class="col-md-12">
                      <div class="section-title">Payment Details</div>

                      <div class="table-responsive">
                          <table class="table table-striped table-hover table-md">
                              <tr>
                                  <th>Fee Item</th>
                                  <th class="text-center">Amount</th>
                                  <th class="text-right">Total</th>
                              </tr>
                              <tr>
                                  <td><?php echo e($paymentData->paymentDetails['feeName']); ?></td>
                                  <?php

                                  $amount = $paymentData->paymentDetails['feeAmount'] ??= 0;
                                  ?>
                                  <td class="text-center">&#8358;<?php echo e(number_format($amount)); ?> </td>

                                  <td class="text-right">&#8358; <?php echo e(number_format($amount)); ?> </td>
                              </tr>
                          </table>
                      </div>
                      <div class="row mt-4">
                          <div class="col-lg-8">
                              <div class="section-title"></div>
                              <p class="section-lead">

                                  <img src="<?php echo e(asset('public/assets/img/cards/remita.png')); ?>" alt="paystack" width="160px" class="center" />

                                  <a href="<?php echo e($paymentData->paymentDetails['paymentUrl']); ?>" class="btn btn-success btn-icon icon-left" target="_blank">
                                      PAY ONLINE NOW </a>

                              </p>

                          </div>


                          <hr class="mt-2 mb-2">
                          <div class="invoice-detail-item">
                              <div class="invoice-detail-name">Total</div>
                              <div class="invoice-detail-value invoice-detail-value-lg">&#8358; <?php echo e(number_format($amount)); ?> </div>
                          </div>
                          <hr class="mt-2 mb-2">

                      </div>
                  </div>
              </div>
          </div>

          <hr>

  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admissions.applicants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northwest\resources\views/admissions/applicants/epaymentslip.blade.php ENDPATH**/ ?>